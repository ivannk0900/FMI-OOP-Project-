package ww1;

public interface IFrontBookkeeper {
	
    String updateFront(String[] news);
    
}
